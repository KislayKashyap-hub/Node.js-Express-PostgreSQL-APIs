--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.11 (Ubuntu 14.11-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "StudentScore";
--
-- Name: StudentScore; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "StudentScore" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_IN';


ALTER DATABASE "StudentScore" OWNER TO postgres;

\connect "StudentScore"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "StudentScore"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "StudentScore" IS 'This is SQL Database of StudentScore';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: coursemodules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coursemodules (
    id integer NOT NULL,
    course_id integer NOT NULL,
    module_id integer NOT NULL
);


ALTER TABLE public.coursemodules OWNER TO postgres;

--
-- Name: coursemodules_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.coursemodules ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."coursemodules_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    type character varying(50),
    modility character varying(20),
    duration integer
);


ALTER TABLE public.courses OWNER TO postgres;

--
-- Name: courses_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.courses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."courses_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: modules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modules (
    id integer NOT NULL,
    name character varying NOT NULL,
    max_score real NOT NULL
);


ALTER TABLE public.modules OWNER TO postgres;

--
-- Name: modules_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.modules ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."modules_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentcourses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentcourses (
    id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    max_score real NOT NULL,
    my_score real NOT NULL
);


ALTER TABLE public.studentcourses OWNER TO postgres;

--
-- Name: studentcourses_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentcourses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."studentcourses_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    password character varying(20),
    added_on character varying(10),
    modified_on character varying(10)
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.students ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."students_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: studentscore; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.studentscore (
    id integer NOT NULL,
    student_id integer NOT NULL,
    coursemodule_id integer NOT NULL,
    my_score real NOT NULL
);


ALTER TABLE public.studentscore OWNER TO postgres;

--
-- Name: studentscore_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.studentscore ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.studentscore_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: coursemodules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coursemodules (id, course_id, module_id) FROM stdin;
\.
COPY public.coursemodules (id, course_id, module_id) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.courses (id, name, type, modility, duration) FROM stdin;
\.
COPY public.courses (id, name, type, modility, duration) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.modules (id, name, max_score) FROM stdin;
\.
COPY public.modules (id, name, max_score) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: studentcourses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentcourses (id, student_id, course_id, max_score, my_score) FROM stdin;
\.
COPY public.studentcourses (id, student_id, course_id, max_score, my_score) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, first_name, last_name, password, added_on, modified_on) FROM stdin;
\.
COPY public.students (id, first_name, last_name, password, added_on, modified_on) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: studentscore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.studentscore (id, student_id, coursemodule_id, my_score) FROM stdin;
\.
COPY public.studentscore (id, student_id, coursemodule_id, my_score) FROM '$$PATH$$/3398.dat';

--
-- Name: coursemodules_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."coursemodules_Id_seq"', 30, true);


--
-- Name: courses_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."courses_Id_seq"', 3, true);


--
-- Name: modules_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."modules_Id_seq"', 25, true);


--
-- Name: studentcourses_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."studentcourses_Id_seq"', 3, true);


--
-- Name: students_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."students_Id_seq"', 13, true);


--
-- Name: studentscore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.studentscore_id_seq', 32, true);


--
-- Name: coursemodules coursemodules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursemodules
    ADD CONSTRAINT coursemodules_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: studentcourses studentcourses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcourses
    ADD CONSTRAINT studentcourses_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: studentscore studentscore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentscore
    ADD CONSTRAINT studentscore_pkey PRIMARY KEY (id);


--
-- Name: studentcourses CourseId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcourses
    ADD CONSTRAINT "CourseId" FOREIGN KEY (course_id) REFERENCES public.courses(id) NOT VALID;


--
-- Name: studentcourses StudentId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentcourses
    ADD CONSTRAINT "StudentId" FOREIGN KEY (student_id) REFERENCES public.students(id) NOT VALID;


--
-- Name: coursemodules course_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursemodules
    ADD CONSTRAINT course_id FOREIGN KEY (course_id) REFERENCES public.courses(id) NOT VALID;


--
-- Name: studentscore coursemodule_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentscore
    ADD CONSTRAINT coursemodule_id FOREIGN KEY (coursemodule_id) REFERENCES public.coursemodules(id) NOT VALID;


--
-- Name: coursemodules module_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coursemodules
    ADD CONSTRAINT module_id FOREIGN KEY (module_id) REFERENCES public.modules(id) NOT VALID;


--
-- Name: studentscore student_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.studentscore
    ADD CONSTRAINT student_id FOREIGN KEY (student_id) REFERENCES public.students(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

